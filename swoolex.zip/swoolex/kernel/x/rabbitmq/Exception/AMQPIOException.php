<?php
namespace x\rabbitmq\Exception;

class AMQPIOException extends \Exception implements AMQPExceptionInterface
{
}
