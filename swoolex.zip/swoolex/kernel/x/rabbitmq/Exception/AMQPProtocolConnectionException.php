<?php
namespace x\rabbitmq\Exception;

class AMQPProtocolConnectionException extends AMQPProtocolException
{
}
