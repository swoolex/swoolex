<?php
namespace x\rabbitmq\Exception;

class AMQPIOWaitException extends AMQPRuntimeException
{
}
