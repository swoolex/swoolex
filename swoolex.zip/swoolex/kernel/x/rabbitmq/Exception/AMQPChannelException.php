<?php
namespace x\rabbitmq\Exception;

/**
 * @deprecated use AMQPProtocolChannelException instead
 */
class AMQPChannelException extends AMQPException
{
}
