<?php
namespace x\rabbitmq\Exception;

class AMQPRuntimeException extends \RuntimeException implements AMQPExceptionInterface
{
}
