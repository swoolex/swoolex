<?php
namespace x\rabbitmq\Exception;

class AMQPProtocolChannelException extends AMQPProtocolException
{
}
