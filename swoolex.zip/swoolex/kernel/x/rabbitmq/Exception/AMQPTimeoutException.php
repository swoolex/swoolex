<?php
namespace x\rabbitmq\Exception;

class AMQPTimeoutException extends \RuntimeException implements AMQPExceptionInterface
{
}
