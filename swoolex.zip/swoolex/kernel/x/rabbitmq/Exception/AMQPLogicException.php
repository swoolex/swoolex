<?php
namespace x\rabbitmq\Exception;

class AMQPLogicException extends \LogicException implements AMQPExceptionInterface
{

}
