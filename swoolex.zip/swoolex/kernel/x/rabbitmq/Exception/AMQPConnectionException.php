<?php
namespace x\rabbitmq\Exception;

/**
 * @deprecated use AMQPProtocolConnectionException instead
 */
class AMQPConnectionException extends AMQPException
{
}
