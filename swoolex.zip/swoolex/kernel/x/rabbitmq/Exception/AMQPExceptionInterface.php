<?php
namespace x\rabbitmq\Exception;

interface AMQPExceptionInterface
{
}
